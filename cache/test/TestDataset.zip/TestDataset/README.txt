========ABOUT THIS FOLDER=====

This folder include the test dataset of DoMo-Pred Web Interface
For each analyze you should include a PWM file and a domain.txt file.

========EVALUATION============

In this evealuation,you should random pick up a pwm file in pwm_dir and use doamin.txt in this root folder.

========PERFORMANCE===========

Due to server's performance,analyze may take up to 45 seconds.
If there are multi requests,you may encounter MemoyError due to the server have only 1 GB memory.

